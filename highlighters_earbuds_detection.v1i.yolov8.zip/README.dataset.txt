# highlighters_earbuds_detection > 2024-12-23 7:08am
https://universe.roboflow.com/yolov8-dataset-41ml5/highlighters_earbuds_detection

Provided by a Roboflow user
License: CC BY 4.0

